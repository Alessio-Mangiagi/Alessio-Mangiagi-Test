import zipfile
import os

directory = "C:/Users/Alessio Mangiagi/Desktop/progetto epicode"

# Estrazione file :ZIP dalle cartelle
def estrai_zip(directory):
    # Usa os.walk per scorrere ricorsivamente nella directory e nelle sottodirectory
    for root, dirs, files in os.walk(directory):
        for file_name in files:
            # Verifica se il file è un file ZIP
            if file_name.endswith('.zip'):
                file_path = os.path.join(root, file_name)
                
                # Crea una cartella con lo stesso nome 
                extract_folder = os.path.join(root, file_name[:-4])
                os.makedirs(extract_folder, exist_ok=True)
                
                # Estrai il file ZIP
                with zipfile.ZipFile(file_path, 'r') as zip_ref:
                    zip_ref.extractall(extract_folder)
                
                print(f"File {file_name} estratto in {extract_folder}")



# Chiama la funzione per estrarre tutti i file ZIP
estrai_zip(directory)



