import csv

# INSERT per una riga
def genera_sql_insert(tabella, colonne, valori):
    valori_sql = [f"'{valore}'" if not valore.isdigit() else valore for valore in valori]
    return f"INSERT INTO {tabella} ({', '.join(colonne)}) VALUES ({', '.join(valori_sql)});"

# Inserisci qui il nome del file csv
nome_tabella = 'bev_share_new_ev12'  
file_input = ("C:\\Users\\Alessio Mangiagi\\Desktop\\Archivi trasformati\\da_csv_a_sql\\bev_share_new_ev12.csv")  # Inserisci il nome del file CSV

# nome file trasformato
file_output_sql = 'bev_share_new_ev.sql'

# trasformazione in upload sql
with open(file_input, 'r', newline='', encoding='utf-8') as csvfile:
    lettore_csv = csv.reader(csvfile)
    # intestazioni
    colonne = next(lettore_csv)  

    with open(file_output_sql, 'w', encoding='utf-8') as sqlfile:
        for riga in lettore_csv:
            comando_sql = genera_sql_insert(nome_tabella, colonne, riga)
            sqlfile.write(comando_sql + '\n')

print(f"Il file è pronto : {file_output_sql}")
