import csv
import os

def convert_tsv_to_csv(tsv_file, csv_file):
    with open(tsv_file, 'r', newline='', encoding='utf-8') as tsv_f:
        reader = csv.reader(tsv_f, delimiter='\t')
        with open(csv_file, 'w', newline='', encoding='utf-8') as csv_f:
            writer = csv.writer(csv_f)
            for row in reader:
                writer.writerow(row)

def convert_all_tsv_in_directory(directory):
    for filename in os.listdir(directory):
        if filename.endswith('.tsv'):
            tsv_file_path = os.path.join(directory, filename)
            csv_file_path = os.path.join(directory, filename[:-4] + '.csv')
            convert_tsv_to_csv(tsv_file_path, csv_file_path)
            print(f"Conversione completata: {tsv_file_path} è stato convertito in {csv_file_path}.")

if __name__ == "__main__":
    # INserisci il percorso della cartella con i file .TSV
    directory_path = 'C:/Users/Alessio Mangiagi/Desktop/Archivi trasformati/file zip'
    
    convert_all_tsv_in_directory(directory_path)
