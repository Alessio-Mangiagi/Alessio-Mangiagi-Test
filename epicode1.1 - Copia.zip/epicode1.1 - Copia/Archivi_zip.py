import gzip
import shutil
import os

# Estrazione .gz
def estrai_gz(directory):
    for root, dirs, files in os.walk(directory):
        for file_name in files:
            if file_name.endswith('.gz'):
                file_path = os.path.join(root, file_name)
                
                # Determina il nome del file estratto 
                extract_file_name = file_name[:-3] 
                extract_file_path = os.path.join(root, extract_file_name)
                
                # Controlla se il file esiste già
                if os.path.exists(extract_file_path):
                    print(f"File {extract_file_path} esiste già.")
                    continue
                
                # Estrazione .gz
                try:
                    with gzip.open(file_path, 'rb') as f_in:
                        with open(extract_file_path, 'wb') as f_out:
                            shutil.copyfileobj(f_in, f_out)
                    print(f"File {file_name} estratto in {extract_file_path}")
                except PermissionError:
                    print(f"Permesso negato: impossibile scrivere il file {extract_file_path}")

# Nome della cartella in cui si trovano i file ZIP
directory = "C:\\Users\\Alessio Mangiagi\\Desktop\\Archivi trasformati\\file zip\\csv"

estrai_gz(directory)









