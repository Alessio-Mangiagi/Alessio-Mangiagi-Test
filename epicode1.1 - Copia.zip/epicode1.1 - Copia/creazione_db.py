import os
import pandas as pd
import sqlite3

# cartella con i file
cartella_csv = "C:\\Users\\Alessio Mangiagi\\Desktop\\Archivi trasformati\\da_csv_a_sql"

# Nome del file del db SQLite
nome_db = "bev_share_new_ev.sql"

# Connessione al db (se non esiste, verrà creato)
conn = sqlite3.connect(nome_db)

# Scorri tutti i file nella cartella
for file in os.listdir(cartella_csv):
    if file.endswith(".csv"):
        file_path = os.path.join(cartella_csv, file)
        
        # Leggi il file CSV in un DataFrame
        df = pd.read_csv(file_path)
        
        # Utilizza il nome del file (senza estensione) come nome della tabella
        nome_tabella = os.path.splitext(file)[0]
        
        # Scrivi il DataFrame nel database come una nuova tabella
        df.to_sql(nome_tabella, conn, if_exists="replace", index=False)
        print(f"Tabella '{nome_tabella}' creata nel database.")
        
# Chiudi la connessione al db
conn.close()
