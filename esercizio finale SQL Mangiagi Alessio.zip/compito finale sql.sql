create database toysgroup  ;
use  toysgroup;

create table product (
						Id_prodotto int primary key,
						Nome_prodotto varchar(150),
						Categoria varchar(100),
						giacenza int
);
create table region (
						Id_regione int primary key,
						area_geografica varchar(150),
						nazione varchar(100),
						città char(10)
);
create table sales (
						Id_vendita int primary key,
						Id_prodotto int,
						Id_regione int,
						data_vendita date,
						Qant_venduto int,
						prezzo decimal(10,2),
						foreign key (Id_prodotto) references product (Id_prodotto),
						foreign key (Id_regione) references region (Id_regione)
);

insert into product (Id_prodotto,Nome_prodotto,Categoria,giacenza) values
					(1,'Chitarra_di_gomma','strumenti',10),
					(2,'ps5','consol_videogame',20),
					(3,'ps5_pro','consol_videogame',3),
					(4,'Spada_di_gomma','giocattolo',49),
					(5,'scudo_di_gomma','giocattolo',0),
					(6,'orologio_peppa_pig','orologio',90),
					(7,'orologio_spiderman','orologio',1)
;

insert into region (Id_regione,area_geografica,nazione,città) values
					(1,'europa','Italia','Catania'),
					(2,'europa','Spagra','Bilbao'),
					(3,'europa','Francia','Lione'),
					(4,'usa','Montan','Yellowstone'),
					(5,'usa','New Hampshire','Concord'),
					(6,'sudAmerica','Brasile','Brasilia'),
					(7,'sudAmerica','Argentina','Buenos Aires')
;

INSERT INTO sales (Id_vendita, Id_prodotto, Id_regione, data_vendita, Qant_venduto, prezzo) VALUES
					(1, 2, 1, '2014-12-27', 10, 20.99),
					(2, 3, 2, '2000-08-27', 8, 15.75),
					(3, 4, 1, '2003-06-08', 15, 30.99),
					(4, 5, 3, '1990-12-21', 5, 10.25),
					(5, 6, 2, '2009-03-17', 12, 25.99),
					(6, 7, 6, '2004-04-12', 3,100.99),
					(7, 1, 7, '1990-07-03', 1,999.99 )
;
-- Verificare che i campi definiti come PK siano univoci.
SELECT Id_regione, COUNT(*) AS duplicati
FROM region
GROUP BY Id_regione
HAVING COUNT(*) > 1
;
SELECT Id_prodotto, COUNT(*) AS duplicati
FROM product
GROUP BY Id_prodotto
HAVING COUNT(*) > 1
;
SELECT Id_vendita, COUNT(*) AS conteggio
FROM sales
GROUP BY Id_vendita
HAVING COUNT(*) > 1
;
-- Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.
select p.Nome_prodotto, year(s.data_vendita)as anno_vendita , sum(s.Qant_venduto*s.prezzo) as fatturato
from product as p
inner join sales as s 
on p.Id_prodotto = s.Id_prodotto
group by p.Nome_prodotto, year(s.data_vendita)
;
-- Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente. 
select r.area_geografica, YEAR (s.data_vendita) AS anno, SUM(s.Qant_venduto * s.prezzo) AS fatturato
from region as r
inner join sales as s 
on r.Id_regione=s.Id_regione
GROUP BY r.area_geografica, YEAR(s.data_vendita)
ORDER BY YEAR(s.data_vendita), fatturato DESC
;
-- Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato? 
SELECT p.categoria,Nome_prodotto, SUM(s.Qant_venduto) AS quantità_totale
FROM Product p
JOIN Sales s 
ON p.Id_prodotto = s.Id_prodotto
GROUP BY p.categoria,Nome_prodotto
ORDER BY quantità_totale DESC
LIMIT 1
;
-- Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti. 
SELECT p.*
FROM Product p
LEFT JOIN Sales s 
ON p.Id_prodotto = s.Id_prodotto
WHERE s.Id_vendita IS NULL
;
-- v2
SELECT *
FROM Product
WHERE Id_prodotto NOT IN 
						(SELECT DISTINCT Id_prodotto FROM Sales)
;
-- Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).
SELECT p.*, MAX(s.data_vendita) AS ultima_data_vendita
FROM Product p
JOIN Sales s 
ON p.Id_prodotto = s.Id_prodotto
GROUP BY p.Id_prodotto
;

